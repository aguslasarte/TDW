const openModal  = document.getElementById("open-modal");
const closeModal = document.getElementById("close-modal");
const modal      = document.getElementById("modal");
const modalForm  = document.getElementById("modal-form");

// Abrir modal
openModal.addEventListener("click", () => {
  modal.style.display = "flex";
});

// Cerrar con X
closeModal.addEventListener("click", () => {
  modal.style.display = "none";
});

// Cerrar clickeando fuera
modal.addEventListener("click", (e) => {
  if (e.target === modal) modal.style.display = "none";
});

// Submit: cerrar modal y abrir feedback
modalForm.addEventListener("submit", function(e) {
  e.preventDefault();
  const nombre = document.getElementById("modal-nombre").value.trim().split(" ")[0];
  modal.style.display = "none";
  modalForm.reset();

  const overlay    = document.getElementById("feedback-overlay");
  const spanNombre = document.getElementById("feedback-nombre");
  spanNombre.textContent = nombre;
  overlay.classList.add("visible");
  document.body.style.overflow = "hidden";
});
